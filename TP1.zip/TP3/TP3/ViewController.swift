//
//  ViewController.swift
//  TP3
//
//  Created by COLONNA FRANCK on 21/09/2021.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let scrollView = UIScrollView(frame: self.view.frame)
        scrollView.backgroundColor = UIColor.black
        
        for(i, num) in multiples(n: 2).enumerated() {
            let view = setupScrollview(number: num, index: i)
            scrollView.contentSize.height += 50
            scrollView.addSubview(view)
        }
        view.addSubview(scrollView)
    }
    
    func multiples(n:Int)->[Int]{
        var tab: [Int] = []
        for i in 0...10000 {
            tab.append(i*2)
        }
        return tab
    }
    
    let colors = [UIColor.gray, UIColor.darkGray]
    
    func setupScrollview(number:Int, index:Int)->UIView{
        let innerView = UIView(frame: CGRect(x:0, y:(0.10*self.view.frame.maxY + CGFloat(50*index)), width: self.view.frame.maxX, height: 60))
        innerView.backgroundColor = colors[index%2]
        let label = UILabel(frame: CGRect(x:0.5*self.view.frame.maxX, y: 0, width: 150, height:40))
        label.textAlignment = .left
        label.text = String(number)
        label.textColor = UIColor.purple
        innerView.addSubview(label)
        return innerView
    }
}

