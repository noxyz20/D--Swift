//
//  ViewController.swift
//  Hello-World
//
//  Created by COLONNA FRANCK on 15/09/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var right: UILabel!
    @IBOutlet weak var left: UILabel!
    @IBOutlet weak var middle: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    @IBAction func roll(_ sender: Any) {
        let r = Int.random(in: 1..<7)
        let l = Int.random(in: 1..<7)
        let m = Int.random(in: 1..<7)
        right.text = String(r)
        left.text = String(l)
        middle.text = String(m)
        
        if (r == 7 && m == 6 && l == 6) {
            print("GAGNER")
        }
    }


}

