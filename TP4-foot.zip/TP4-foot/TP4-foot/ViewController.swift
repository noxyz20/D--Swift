//
//  ViewController.swift
//  TP4-foot
//
//  Created by COLONNA FRANCK on 21/09/2021.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    var parse: [String:[[String:String]]] = [:]
    override func viewDidLoad() {
        super.viewDidLoad()
     

        let path = Bundle.main.path(forResource: "scb_resultats", ofType: "json")
        let data:NSData = try! NSData(contentsOfFile: path!)
      
        do {
            parse = try JSONSerialization.jsonObject(with: data as Data, options: .allowFragments) as! [String:[[String:String]]]
            
        } catch let error as NSError {
                print(error)
        }

        
        let scroll = UITableView(frame: self.view.frame)
        scroll.register(UITableViewCell.self, forCellReuseIdentifier: "toto")
        self.view.addSubview(scroll)
        scroll.delegate = self
        scroll.dataSource = self
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int)-> Int {
        return parse["resultats"]!.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath)-> UITableViewCell {
        let innerView = UITableViewCell()
        
        let date = UILabel(frame: CGRect(x:20, y: -5, width: innerView.frame.maxX, height:40))
        date.textAlignment = .left
        date.text = parse["resultats"]![indexPath.row]["date"]
        date.autoresizingMask = [.flexibleWidth]
        date.textColor = UIColor.lightGray
        date.font = UIFont.boldSystemFont(ofSize: 10.0)
        
        let domName = UILabel(frame: CGRect(x:20, y: 10, width: innerView.frame.maxX*0.3, height:40))
        domName.textAlignment = .left
        domName.text = parse["resultats"]![indexPath.row]["dom_name"]
        domName.autoresizingMask = [.flexibleWidth, .flexibleRightMargin]
        
        let extName = UILabel(frame: CGRect(x:0.7*innerView.frame.maxX, y: 10, width: innerView.frame.width*0.3-20, height:40))
        extName.textAlignment = .right
        extName.text = parse["resultats"]![indexPath.row]["ext_name"]
        extName.autoresizingMask = [.flexibleWidth, .flexibleLeftMargin]
        
        let score = UILabel(frame: CGRect(x:0.3*innerView.frame.maxX, y: 10, width: innerView.frame.width*0.3, height:40))
        score.textAlignment = .center
        score.autoresizingMask = [.flexibleWidth, .flexibleLeftMargin, .flexibleRightMargin]
        
        if(parse["resultats"]![indexPath.row]["score"] != "") {
            score.text = parse["resultats"]![indexPath.row]["score"]
        } else {
            score.text = "-"
        }
        
        innerView.addSubview(date)
        innerView.addSubview(domName)
        innerView.addSubview(score)
        innerView.addSubview(extName)
        
        score.center = innerView.center
        
        return innerView
    }

}

