//
//  ViewController.swift
//  tp1 correction
//
//  Created by COLONNA FRANCK on 21/09/2021.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let scroll = UITableView(frame: self.view.frame)
        scroll.register(UITableViewCell.self, forCellReuseIdentifier: "toto")
        self.view.addSubview(scroll)
        scroll.delegate = self
        scroll.dataSource = self
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int)-> Int {
        return 10000
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath)-> UITableViewCell {
        let innerView = UITableViewCell(frame: CGRect(x:0, y:(0.10*self.view.frame.maxY + CGFloat(50*indexPath.row)), width: self.view.frame.maxX, height: 60))
        let label = UILabel(frame: CGRect(x:0, y: 0, width: self.view.frame.maxX, height:40))
        label.textAlignment = .center
        label.text = String(indexPath.row*2)
        label.textColor = UIColor.purple
        innerView.addSubview(label)
        return innerView
    }

}

